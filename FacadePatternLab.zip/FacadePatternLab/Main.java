public class Main {
    public static void main(String[] args) {
        FlightBookingFacade bookingFacade = new FlightBookingFacade();
        String testCard = "4532015112830366";

        System.out.println("=== TEST 1: Standard successful booking ===");
        String ticket1 = bookingFacade.bookFlight(
                "Amina Suleimenova", "KZ204", "14B", 320.00, 2, 24.5, "EUR", testCard);
        System.out.println("Result 1: " + ticket1);
        System.out.println();

        System.out.println("=== TEST 2: Blocked crew seat ===");
        String ticket2 = bookingFacade.bookFlight(
                "Daniyar Kassymov", "KZ204", "13A", 320.00, 1, 15.0, "USD", testCard);
        System.out.println("Result 2: " + ticket2);
        System.out.println();

        System.out.println("=== TEST 3: Failed payment and seat rollback ===");
        String ticket3 = bookingFacade.bookFlight(
                "Timur Bekov", "KZ204", "08C", 320.00, 1, 18.0, "KZT", "1234");
        System.out.println("Result 3: " + ticket3);
        System.out.println();

        System.out.println("=== TEST 4: SILVER baggage waiver and promo ===");
        String ticket4 = bookingFacade.bookFlight(
                "Madina Akhmetova", "KZ204", "15D", 320.00, 3, 30.0, "USD", testCard, "SILVER");
        System.out.println("Result 4: " + ticket4);
    }
}
