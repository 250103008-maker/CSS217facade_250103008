public class FlightBookingFacade {
    private final SeatInventorySystem seatSystem;
    private final BaggagePricingEngine baggageEngine;
    private final CurrencyConverter currencyConverter;
    private PaymentProcessor paymentProcessor;
    private final TicketIssuer ticketIssuer;

    public FlightBookingFacade() {
        seatSystem = new SeatInventorySystem();
        baggageEngine = new BaggagePricingEngine();
        currencyConverter = new CurrencyConverter();
        paymentProcessor = new PaymentProcessor();
        ticketIssuer = new TicketIssuer();
    }

    public String bookFlight(String passengerName, String flightCode, String seatNumber,
                             double baseFareUSD, int bagCount, double bagWeightKg,
                             String currency, String cardNumber) {
        return bookFlight(passengerName, flightCode, seatNumber, baseFareUSD,
                          bagCount, bagWeightKg, currency, cardNumber, "STANDARD");
    }

    public synchronized String bookFlight(String passengerName, String flightCode, String seatNumber,
                                          double baseFareUSD, int bagCount, double bagWeightKg,
                                          String currency, String cardNumber, String loyaltyTier) {
        boolean silverTier = "SILVER".equalsIgnoreCase(loyaltyTier);
        boolean freeBaggage = silverTier || "GOLD".equalsIgnoreCase(loyaltyTier);
        String lockToken = null;
        boolean promoPending = false;
        try {
            seatSystem.connectToReservationServer();
            lockToken = seatSystem.lockSeat(flightCode, seatNumber, passengerName);

            double baggageFeeUSD = freeBaggage
                    ? 0.0
                    : baggageEngine.calculateBaggageFeeUSD(bagCount, bagWeightKg);
            double totalUSD = baseFareUSD + baggageFeeUSD;
            double convertedTotal = currencyConverter.convertFromUSD(totalUSD, currency);

            paymentProcessor.initializeGateway();
            if (silverTier) {
                paymentProcessor.applyPromoCode("SILVER-FREE-BAG");
                promoPending = true;
            }
            String receiptId = paymentProcessor.chargeCard(cardNumber, convertedTotal, currency);
            promoPending = false;
            return ticketIssuer.generateTicket(passengerName, flightCode, lockToken, receiptId);
        } catch (RuntimeException ex) {
            if (lockToken != null) {
                seatSystem.releaseSeatLock(lockToken);
            }
            if (promoPending) {
                // A declined charge leaves the promo set on the processor.
                paymentProcessor = new PaymentProcessor();
            }
            String failure = "BOOKING_FAILED: " + ex.getMessage();
            System.out.println("[FlightBookingFacade] " + failure);
            return failure;
        } finally {
            seatSystem.disconnect();
        }
    }
}
